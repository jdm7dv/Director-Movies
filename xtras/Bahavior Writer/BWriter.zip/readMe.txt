Behavior Writer  - 7 March 1998  by  Roy Pardi  - (rpardi@tiac.net)


This is the Behavior Writer Xtra, a shareware authoring utility for Director 6. 
Its sole purpose is to make writing the core behavior structure faster and easier. Drag the file into the xtras folder on your hard drive and relaunch Director. The Behavior Writer will appear under the Xtras menu.

Version .12b Free of all known bugs. Please send bug reports and suggestions to: rpardi@tiac.net

Main Screen

--Name
The name of the behavior

--Tag
A place for a short descriptive line which will display in the castLib thumbnail of this script

--Description
The behavior description which will appear in the behavior inspector window. 
Returns are legal

--CastLib
A pull-down menu listing the castLibs in the current movie. 
Use this to select the castLib to write the script to.

--Add
Add a property

--Edit
Edit the property currently listed in the pulldown menu at the right. 
To edit a property, select it from this, then press 'Edit'

--Write It
Writes out the behavior

--Cancel
Closes the Behavior Writer window


Adding/Editing Properties Screen
There is a fair amount of error checking for correct formats and data type for the data entered in these fields but it does not cover every variation. (What fun would that be?) 
--Property
This is the name of the property. It is required. Properties cannot begin with numerals or contain spaces. These characters are filtered for this field. A lower case "p" is added before each property name. This is simply a convention which many people use for readability. This can not be disabled.

--Default
The default value. If value entered here does not match the format specified, you will recieve an alert message.

--Comment
The comment which will appear for this property in the property dialogue box.

-Range checkbox
The range checkbox, when enabled, has two states depending on the format currently selected. If the format is integer or float, you will be presented with min + max fields. This will result in a slider widget in the property dialogue box. If the format is other than this, a scrolling field will be presented. This will result in a pull-down menu in the property dialogue box. Changing formats when range is selected should automatically present the proper screen. 


Preferences
The options set in this screen will be applied to each behavior created.

--event handlers
The events in the left field will be added to every behavior in the order listed. Click on the left field to delete an event. Click on the right field to add an event.

--date & Author ID
The date and contents of author field are added as comments at the top of the script

--Clear behavior settings
Enabling this option will clear all settings once a behavior is written. Disable this option if you need to create a set of behaviors which will have the same or similar properties.

--Property name for spriteNum
I'm lazy + its boring to write "the spriteNum of me" over and over. Enabling this option will store the spriteNum as a property of the name you provide in the associated field. This property is initializied in a beginSprite handler. If you do not have 'beginSprite' as a defualt event andd this option is enabled, a beginSprite handler will be added.

--Bold event names
What it sez


Behavior Writer Xtra is fully functional shareware. 
If you like it and use it, please send $10 to:

Roy Pardi
55 Hawthorne Street
Somerville, MA 02144

	
Behavior Writer  copyright Roy Pardi 1998  (rpardi@tiac.net)
