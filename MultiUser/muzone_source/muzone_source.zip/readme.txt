This archive contains the following files:

intro.dir         ----  File for display while preloading scripts

standardUser.dir  ----  Chat environment for normal users
moderator.dir     ----  Chat environment for event moderators
guestSpeaker.dir  ----  Chat environment for event guests
guestAvatars.cst  ----  External cast for Flash guest avatars. Modifying
                  ----  this cast adds new avatar selections to events
scripts.cst       ----  External linked cast containing all scripts
chair.jpg         ----  External linked jpeg of chair for guest avatar
                  ----  to sit in during event

custom-biz.dir    ----  Business oriented custom chat
custom-game.dir   ----  Game oriented custom chat
custom-wild.dir   ----  Way funky custom chat


The custom chats are experimental and not included in the online version
of the multiuser zone, but are included here for fun and because they're
really cool to play around with.

The multiuser zone code is designed to primarily run in Shockwave, but
can also be easily made into a stand-alone projector as well.